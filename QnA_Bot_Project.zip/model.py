from sentence_transformers import SentenceTransformer
import faiss
import json
import numpy as np

model = SentenceTransformer('all-MiniLM-L6-v2')

with open("data.json", "r") as f:
    data = json.load(f)

questions = [item["question"] for item in data]
answers = [item["answer"] for item in data]

embeddings = model.encode(questions)

dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(embeddings))

def get_answer(query):
    query_vec = model.encode([query])
    D, I = index.search(query_vec, k=1)
    return answers[I[0][0]]
